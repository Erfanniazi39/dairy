@echo off
REM G1 server assessment - read-only. Results go to G1\Server on this drive.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0G1-scripts\Run-All.ps1"
