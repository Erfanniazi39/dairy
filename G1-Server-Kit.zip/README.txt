G1 SERVER ASSESSMENT KIT  (read-only - changes nothing on the server)
=====================================================================

1. Copy EVERYTHING in this folder to the root of a USB stick, so it looks like:
       E:\RUN-G1-SERVER.bat
       E:\RUN-G1-SERVER-QUICK.bat
       E:\G1-scripts\  (the scripts)

2. On the server: plug in the USB, open it, double-click RUN-G1-SERVER.bat
   Click "Yes" when Windows asks for Administrator permission.

3. Wait. Usually 5-15 minutes. A window shows progress.
   If it takes too long, close it and use RUN-G1-SERVER-QUICK.bat instead.

4. When finished, the results folder opens automatically:
       E:\G1\Server\
   Read 00-SUMMARY.txt first: Critical / Warning / Info findings
   and the short list of things to check by hand.

5. Fill in purchase date and warranty at the bottom of 01-identity.txt (Notepad).

6. Bring the USB back. Send 00-SUMMARY.txt (and the other files if asked) for review.
   Never upload the G1\Server results to GitHub - they describe the server's security.

Files produced (in G1\Server):
  00-SUMMARY.txt / 00-summary.csv   all findings, most serious first
  00-run-log.txt                    full log of the run
  01-*   identity: model, serial, CPU, RAM, Windows, license
  02-*   what runs: roles, shares, permissions, software, databases, services, ports, tasks
  03-*   disks: health, free space, wear, errors, RAID
  04-*   health: updates, uptime, antivirus, errors, shutdowns, time
  05-*   access: admins, users, Remote Desktop, failed logons, firewall
  06-*   domain role (+ AD\ folder if the server is a domain controller)
  07-*   backups and UPS

If the antivirus blocks a script: note the antivirus name and message. Do not disable the antivirus.
