@echo off
REM Same as RUN-G1-SERVER.bat but skips share sizes and database-file search (faster).
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0G1-scripts\Run-All.ps1" -Quick
