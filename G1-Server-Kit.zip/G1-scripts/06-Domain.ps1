﻿# G1 server assessment - Section 7: Is the server a domain controller?
# If yes, runs Get-G1ADHealth.ps1 (results in G1\Server\AD). READ-ONLY.
param([string]$OutDir, [switch]$Quick)
. (Join-Path $PSScriptRoot '_common.ps1')
$Area = '7 Domain'

$cs = Get-CimInstance Win32_ComputerSystem
$role = switch ([int]$cs.DomainRole) {
    0 {'Standalone workstation'} 1 {'Member workstation'} 2 {'Standalone server (no domain)'}
    3 {'Member server (domain joined)'} 4 {'Backup domain controller'} 5 {'Primary domain controller'}
}
SaveText @("Domain role : $role", "Domain      : $($cs.Domain)", "Part of domain: $($cs.PartOfDomain)") '06-domain-role.txt'

switch ([int]$cs.DomainRole) {
    2 { Flag 'Info' 'Server is NOT in a domain: users log in with local accounts on each PC' }
    3 { Flag 'Warning' "Server is a member of domain '$($cs.Domain)' but is not a DC: find the domain controller - it is another critical system" }
    { $_ -ge 4 } {
        Step 'This is a domain controller - running AD health check (takes a few minutes)'
        $ad = Join-Path $PSScriptRoot 'Get-G1ADHealth.ps1'
        if (Test-Path $ad) { & $ad -OutDir (Join-Path $OutDir 'AD') | Out-Null }
        $dcs = @(Get-ADDomainController -Filter *)
        if ($dcs.Count -le 1) { Flag 'Critical' "This server is the ONLY domain controller of '$($cs.Domain)': if it fails, nobody can log in" }
        else { Flag 'Info' "Domain '$($cs.Domain)' has $($dcs.Count) domain controllers" }
        $errs = Get-Content (Join-Path $OutDir 'AD\dcdiag-errors-only.txt') | Where-Object { $_ -match 'failed test' }
        if ($errs) { Flag 'Warning' ("dcdiag failed tests: " + (($errs | ForEach-Object { ($_ -split 'failed test')[-1].Trim() }) -join ', ')) }
    }
}
