﻿# G1 server assessment - Section 2: Basic identity (name, model, serial, CPU, RAM, Windows, license, age clues)
# READ-ONLY. Run via RUN-G1-SERVER.bat, or alone in an Administrator PowerShell.
param([string]$OutDir, [switch]$Quick)
. (Join-Path $PSScriptRoot '_common.ps1')
$Area = '2 Identity'

Step 'Hardware and Windows facts'
$os    = Get-CimInstance Win32_OperatingSystem
$cs    = Get-CimInstance Win32_ComputerSystem
$bios  = Get-CimInstance Win32_BIOS
$cpu   = @(Get-CimInstance Win32_Processor)
$mem   = @(Get-CimInstance Win32_PhysicalMemory)
$slots = (Get-CimInstance Win32_PhysicalMemoryArray | Measure-Object MemoryDevices -Sum).Sum
$lic   = Get-CimInstance SoftwareLicensingProduct -Filter "PartialProductKey IS NOT NULL AND Name LIKE 'Windows%'" | Select-Object -First 1

$caption = $os.Caption
$support = switch -Regex ($caption) {
    '2003|2008|2012' { 'UNSUPPORTED'; break }
    '2016'           { 'Support ends 2027-01-12'; break }
    '2019'           { 'Supported until 2029-01-09'; break }
    '2022'           { 'Supported until 2031-10-14'; break }
    '2025'           { 'Supported'; break }
    default          { 'Check Microsoft lifecycle page' }
}
$licStatus = switch ([int]$lic.LicenseStatus) { 1 {'Licensed'} 0 {'Unlicensed'} 2 {'Grace period'} 3 {'Grace period'} 5 {'Notification mode'} default {'Unknown'} }

$diskMax   = (Get-PhysicalDisk | Get-StorageReliabilityCounter | Measure-Object PowerOnHours -Maximum).Maximum
$diskYears = if ($diskMax) { [math]::Round($diskMax / 8760, 1) } else { 'n/a' }

$info = [ordered]@{
    'Server name'          = $os.CSName
    'Brand'                = $cs.Manufacturer
    'Model'                = $cs.Model
    'Serial number'        = $bios.SerialNumber
    'Virtual machine?'     = [bool]($cs.Model -match 'Virtual|VMware|KVM|QEMU|HVM')
    'CPU'                  = "$($cpu[0].Name)".Trim()
    'CPU count'            = $cpu.Count
    'Cores (total)'        = ($cpu | Measure-Object NumberOfCores -Sum).Sum
    'Threads (total)'      = ($cpu | Measure-Object NumberOfLogicalProcessors -Sum).Sum
    'RAM (GB)'             = [math]::Round($cs.TotalPhysicalMemory / 1GB)
    'RAM sticks installed' = $mem.Count
    'RAM slots total'      = $slots
    'RAM slots free'       = if ($slots) { $slots - $mem.Count } else { 'unknown' }
    'Windows version'      = $caption
    'Build'                = "$($os.BuildNumber)"
    'License status'       = $licStatus
    'Support status'       = $support
    'Domain / workgroup'   = $cs.Domain
    'Windows installed'    = "$($os.InstallDate)"
    'BIOS version'         = $bios.SMBIOSBIOSVersion
    'BIOS date'            = "$($bios.ReleaseDate)"
    'Disk power-on years'  = $diskYears
    'Last boot'            = "$($os.LastBootUpTime)"
    'Collected at'         = (Get-Date -Format 'yyyy-MM-dd HH:mm')
}
Save ([pscustomobject]$info) '01-identity.csv'

$ram = $mem | ForEach-Object {
    [pscustomobject]@{ Slot = ("$($_.BankLabel) $($_.DeviceLocator)").Trim(); SizeGB = [math]::Round($_.Capacity/1GB)
                       SpeedMHz = $_.Speed; Maker = "$($_.Manufacturer)".Trim(); PartNumber = "$($_.PartNumber)".Trim() }
}
Save $ram '01-ram-sticks.csv'

$lines  = @("G1 - SERVER IDENTITY : $($os.CSName)", ('=' * 60))
$lines += foreach ($k in $info.Keys) { "{0,-22}: {1}" -f $k, $info[$k] }
$lines += '', ('-' * 60), 'FILL IN BY HAND (no command can find these):',
          '  Purchase date / invoice  : ', '  Seller / importer        : ', '  Local warranty until     : ',
          '  Vendor warranty          : ', '  Estimated age            : ', '  Serial matches sticker?  : ', '  Notes                    : '
SaveText $lines '01-identity.txt'

# Flags
if ($support -eq 'UNSUPPORTED')        { Flag 'Critical' "Windows is out of support: $caption" }
elseif ($support -like '*2027-01-12*') { Flag 'Warning'  "Windows Server 2016 support ends 2027-01-12: plan upgrade/replacement" }
if ($licStatus -ne 'Licensed')         { Flag 'Warning'  "Windows license status: $licStatus" }
if ($diskYears -is [double] -and $diskYears -ge 6) { Flag 'Warning' "Disks have run about $diskYears years: hardware near end of life" }
Flag 'Info' "$($cs.Manufacturer) $($cs.Model), $($info['Cores (total)']) cores, $($info['RAM (GB)']) GB RAM, $caption"
