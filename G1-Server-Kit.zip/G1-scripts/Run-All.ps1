﻿<#
  G1 server assessment - runs every section script and writes a summary of problems.
  READ-ONLY: nothing on the server is changed.

  Normally started by double-clicking RUN-G1-SERVER.bat. Restarts itself as Administrator if needed.
  Results go to <USB>\G1\Server\ ; read 00-SUMMARY.txt first.

  -Quick  skips the slow parts (share sizes, database-file search). Use it if the full run takes too long.
#>
param([switch]$Quick)

# --- Make sure we run as Administrator ---
$me = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host 'Restarting as Administrator (click Yes)...' -ForegroundColor Yellow
    $args2 = "-NoProfile -ExecutionPolicy Bypass -NoExit -File `"$PSCommandPath`""
    if ($Quick) { $args2 += ' -Quick' }
    Start-Process powershell.exe -Verb RunAs -ArgumentList $args2
    exit
}

$OutDir = Join-Path (Split-Path $PSScriptRoot -Parent) 'G1\Server'
New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
$start = Get-Date
Start-Transcript -Path (Join-Path $OutDir '00-run-log.txt') -Force | Out-Null

Write-Host ''
Write-Host "G1 SERVER ASSESSMENT on $env:COMPUTERNAME  (read-only)" -ForegroundColor Cyan
Write-Host "Results: $OutDir"
if ($Quick) { Write-Host 'Quick mode: share sizes and database-file search skipped' -ForegroundColor Yellow }
Write-Host ''

$scripts = '01-Identity.ps1', '02-Services.ps1', '03-Storage.ps1', '04-Health.ps1',
           '05-Access.ps1', '06-Domain.ps1', '07-Backup-UPS.ps1'
$flags = @()
$i = 0
foreach ($s in $scripts) {
    $i++
    $t0 = Get-Date
    Write-Host ("[{0}/{1}] {2}" -f $i, $scripts.Count, $s) -ForegroundColor White
    try {
        $flags += @(& (Join-Path $PSScriptRoot $s) -OutDir $OutDir -Quick:$Quick) |
                  Where-Object { $_ -and $_.PSObject.Properties['Level'] }
    } catch {
        Write-Host "    ERROR in $s : $_" -ForegroundColor Red
        $flags += [pscustomobject]@{ Area = $s; Level = 'Warning'; Finding = "Script error: $_ (rest of the run continued)" }
    }
    Write-Host ("    done in {0:n0} s" -f ((Get-Date) - $t0).TotalSeconds) -ForegroundColor DarkGray
}

# --- Summary ---
$order = @{ Critical = 0; Warning = 1; Info = 2 }
$flags = $flags | Sort-Object { $order[$_.Level] }, Area
$flags | Export-Csv (Join-Path $OutDir '00-summary.csv') -NoTypeInformation -Encoding UTF8

$crit = @($flags | Where-Object Level -eq 'Critical')
$warn = @($flags | Where-Object Level -eq 'Warning')
$info = @($flags | Where-Object Level -eq 'Info')

$out = @()
$out += "G1 SERVER ASSESSMENT - SUMMARY"
$out += "Server : $env:COMPUTERNAME"
$out += "Date   : $(Get-Date -Format 'yyyy-MM-dd HH:mm')   (run took $([int]((Get-Date) - $start).TotalMinutes) min)"
$out += ('=' * 70)
foreach ($grp in @(@('CRITICAL - report to management / fix first', $crit),
                   @('WARNING - goes into the risk register', $warn),
                   @('INFO - facts to record', $info))) {
    $out += ''
    $out += "$($grp[0])  ($(@($grp[1]).Count))"
    $out += ('-' * 70)
    if (@($grp[1]).Count -eq 0) { $out += '  (none)' }
    foreach ($f in $grp[1]) { $out += "  [$($f.Area)] $($f.Finding)" }
}
$out += ''
$out += ('=' * 70)
$out += 'STILL TO DO BY HAND (scripts cannot check these):'
$out += '  - Section 1: physical check + photos (location, lights, cooling, labels)'
$out += '  - Purchase date and warranty  -> fill in at the bottom of 01-identity.txt'
$out += '  - RAID status in iLO / iDRAC / vendor RAID tool (if a hardware RAID controller was found)'
$out += '  - Antivirus last update date (open the antivirus window)'
$out += '  - Backup software: jobs, destination, last success; where the backup copies are kept'
$out += '  - UPS: model, battery age, what else is plugged in'
$out += '  - Section 3.8: ask people what stops if the server is off for a day'
$out | Out-File (Join-Path $OutDir '00-SUMMARY.txt') -Encoding UTF8

Stop-Transcript | Out-Null

Write-Host ''
Write-Host ('=' * 60)
Write-Host ("Critical: {0}   Warning: {1}   Info: {2}" -f $crit.Count, $warn.Count, $info.Count) -ForegroundColor Cyan
foreach ($f in $crit) { Write-Host "  CRITICAL [$($f.Area)] $($f.Finding)" -ForegroundColor Red }
Write-Host ''
Write-Host "Finished. Read first: $OutDir\00-SUMMARY.txt" -ForegroundColor Green
Start-Process explorer.exe $OutDir
