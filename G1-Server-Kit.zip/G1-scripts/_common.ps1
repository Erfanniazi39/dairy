﻿# Shared helpers for the G1 server scripts. Dot-sourced by each script; not run on its own.
$ErrorActionPreference = 'SilentlyContinue'
if (-not $OutDir) { $OutDir = Join-Path (Split-Path $PSScriptRoot -Parent) 'G1\Server' }
New-Item -ItemType Directory -Path $OutDir -Force | Out-Null

function Flag([string]$Level, [string]$Finding) {
    # Level: Critical | Warning | Info. Returned to Run-All for the summary.
    [pscustomobject]@{ Area = $Area; Level = $Level; Finding = $Finding }
}
function Save($Data, [string]$File) {
    if ($null -eq $Data -or @($Data).Count -eq 0) {
        "(nothing found)" | Out-File (Join-Path $OutDir ($File -replace '\.csv$', '.txt')) -Encoding UTF8
    } else {
        @($Data) | Export-Csv (Join-Path $OutDir $File) -NoTypeInformation -Encoding UTF8
    }
}
function SaveText($Text, [string]$File) { $Text | Out-File (Join-Path $OutDir $File) -Encoding UTF8 }
function Step([string]$Msg) { Write-Host "   - $Msg" -ForegroundColor DarkGray }

function Get-InstalledSoftware {
    $paths = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
             'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    Get-ItemProperty $paths | Where-Object { $_.DisplayName -and -not $_.SystemComponent } |
        Select-Object DisplayName, DisplayVersion, Publisher, InstallDate, InstallLocation |
        Sort-Object DisplayName -Unique
}
