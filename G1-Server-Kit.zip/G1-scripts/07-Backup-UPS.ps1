﻿# G1 server assessment - Sections 8 and 9: Backups and UPS
# Windows Server Backup, shadow copies, backup software, backup-like scheduled tasks,
# UPS connection and UPS software. READ-ONLY. (The test restore is a separate, manual G1 step.)
param([string]$OutDir, [switch]$Quick)
. (Join-Path $PSScriptRoot '_common.ps1')
$Area = '8 Backup'
$found = $false

Step 'Windows Server Backup'
$wsb = Get-WindowsFeature Windows-Server-Backup
$wbv = @(wbadmin get versions 2>&1)
SaveText (@("Windows Server Backup installed: $($wsb.Installed)", '') + $wbv) '07-wsb-versions.txt'
$sum = $null
try { $sum = Get-WBSummary } catch {}
if ($sum) {
    Save ($sum | Select-Object LastSuccessfulBackupTime, LastBackupTime, LastBackupResultHR, NextBackupTime, NumberOfVersions, LastBackupTarget) '07-wsb-summary.csv'
    if ($sum.NumberOfVersions -gt 0) {
        $found = $true
        $age = ((Get-Date) - $sum.LastSuccessfulBackupTime).Days
        if ($age -gt 7) { Flag 'Warning' "Windows Server Backup: last success $($sum.LastSuccessfulBackupTime) ($age days ago)" }
        else            { Flag 'Info'    "Windows Server Backup: last success $($sum.LastSuccessfulBackupTime), target $($sum.LastBackupTarget)" }
    }
} elseif (($wbv -join ' ') -match 'Backup time') { $found = $true; Flag 'Info' 'Windows Server Backup versions exist - see 07-wsb-versions.txt' }

Step 'Shadow copies (Previous Versions)'
$vs  = @(vssadmin list shadowstorage 2>&1) + '' + @(vssadmin list shadows 2>&1 | Select-String 'creation time|Original Volume' | ForEach-Object { $_.Line.Trim() })
SaveText $vs '07-shadow-copies.txt'
$shadowCount = @($vs | Where-Object { $_ -match 'creation time' }).Count
if ($shadowCount) { Flag 'Info' "$shadowCount shadow copies exist (useful for file restores, but NOT a backup)" }

Step 'Backup software'
$bsw = Get-InstalledSoftware | Where-Object DisplayName -match 'Veeam|Acronis|Cobian|Uranium|Macrium|EaseUS|AOMEI|Iperius|Backup Exec|Arcserve|NAKIVO|Altaro|Duplicati|FBackup|SyncBack|GoodSync|Paragon|Bvckup|Areca|UrBackup|Handy Backup'
Save $bsw '07-backup-software.csv'
if ($bsw) { $found = $true; Flag 'Info' ("Backup software: " + (($bsw.DisplayName) -join ', ') + " - open it and note jobs, destination, last success") }

Step 'Backup-like scheduled tasks and SQL backup files'
$bt = Get-ScheduledTask | Where-Object { $_.TaskPath -notlike '\Microsoft\*' } | ForEach-Object {
    $act = ($_.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join '; '
    if ("$($_.TaskName) $act" -match 'backup|bak|robocopy|xcopy|sqlcmd|7z|rar|zip|copy') {
        $i = $_ | Get-ScheduledTaskInfo
        [pscustomobject]@{ Task = $_.TaskName; State = $_.State; LastRun = $i.LastRunTime; LastResult = $i.LastTaskResult; Action = $act }
    }
}
Save $bt '07-backup-tasks.csv'
if ($bt) { $found = $true; Flag 'Info' "$(@($bt).Count) scheduled task(s) look like backup/copy jobs - see 07-backup-tasks.csv" }

$bakFile = Join-Path $OutDir '02-database-files.csv'
if (Test-Path $bakFile) {
    $baks = Import-Csv $bakFile | Where-Object FullName -like '*.bak' | Sort-Object { try { [datetime]::Parse($_.LastWriteTime) } catch { [datetime]::MinValue } } -Descending
    if ($baks) { $found = $true; Flag 'Info' ("Newest database .bak file: $($baks[0].FullName) ($($baks[0].LastWriteTime)) - is it copied off this server?") }
}

if (-not $found) { Flag 'Critical' 'No backup of any kind found on this server - confirm by asking (accounting software backups, USB copies)' }
Flag 'Info' 'Reminder: no backup counts until a test restore works (G1 item 7)'

$Area = '9 UPS'
Step 'UPS'
$bat = Get-CimInstance Win32_Battery | Select-Object Name, DeviceID, Status, EstimatedChargeRemaining, EstimatedRunTime, BatteryStatus
Save $bat '07-ups.csv'
$ups = Get-InstalledSoftware | Where-Object DisplayName -match 'PowerChute|ViewPower|WinPower|UPSilon|Eaton|Intelligent Power|NUT|Network UPS|Riello|PowerMaster|PowerPanel|Faratel|Hirad|UPSMON|SANTAK|Delta|Vertiv|Liebert'
Save $ups '07-ups-software.csv'
if (-not $bat -and -not $ups) { Flag 'Warning' 'No UPS connection or UPS software detected: on a long power cut the server will crash (check physically)' }
elseif ($bat)                 { Flag 'Info' ("UPS connected: $($bat[0].Name), charge $($bat[0].EstimatedChargeRemaining)%, est. runtime $($bat[0].EstimatedRunTime) min") }
else                          { Flag 'Info' ("UPS software installed: " + (($ups.DisplayName) -join ', ')) }
