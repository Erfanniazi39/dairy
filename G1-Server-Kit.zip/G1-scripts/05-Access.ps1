﻿# G1 server assessment - Section 6: Access and security
# Local admins, local users, Remote Desktop settings and logons, failed logons, SMBv1,
# local password policy, firewall. READ-ONLY.
param([string]$OutDir, [switch]$Quick)
. (Join-Path $PSScriptRoot '_common.ps1')
$Area = '6 Access'
$isDC = (Get-CimInstance Win32_ComputerSystem).DomainRole -ge 4

Step 'Local Administrators group'
$admGroup = (New-Object System.Security.Principal.SecurityIdentifier('S-1-5-32-544')).Translate([System.Security.Principal.NTAccount]).Value.Split('\')[-1]
$admins = @()
try {
    $grp = [ADSI]"WinNT://./$admGroup,group"
    $admins = $grp.Invoke('Members') | ForEach-Object {
        $path = $_.GetType().InvokeMember('ADsPath', 'GetProperty', $null, $_, $null)
        $cls  = $_.GetType().InvokeMember('Class',   'GetProperty', $null, $_, $null)
        [pscustomobject]@{ Member = ($path -replace '^WinNT://', '' -replace '/', '\'); Type = $cls }
    }
} catch {}
Save $admins '05-local-admins.csv'
if (@($admins).Count -gt 3) { Flag 'Warning' "$(@($admins).Count) members in local Administrators - review who really needs it" }

if (-not $isDC) {
    Step 'Local user accounts'
    $lu = Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' | Select-Object Name, Disabled, Lockout, PasswordExpires, PasswordRequired, Description, SID
    Save $lu '05-local-users.csv'
    $builtin = $lu | Where-Object { $_.SID -match '-500$' -and -not $_.Disabled }
    if ($builtin) { Flag 'Info' "Built-in Administrator account '$($builtin.Name)' is enabled (who knows its password?)" }
    foreach ($u in $lu | Where-Object { -not $_.Disabled -and -not $_.PasswordRequired }) { Flag 'Critical' "Local account '$($u.Name)' does not require a password" }
}
SaveText (net accounts 2>&1) '05-password-policy.txt'

Step 'Remote Desktop'
$ts    = Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server'
$rdpTcp = Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp'
$rdpOn = $ts.fDenyTSConnections -eq 0
SaveText @("RDP enabled : $rdpOn", "RDP port    : $($rdpTcp.PortNumber)", "NLA required: $($rdpTcp.UserAuthentication -eq 1)") '05-rdp-settings.txt'
if ($rdpOn -and $rdpTcp.UserAuthentication -ne 1) { Flag 'Warning' 'Remote Desktop is enabled without Network Level Authentication' }

Step 'Remote Desktop logons (last 30 days)'
$xp = "*[System[(EventID=4624) and TimeCreated[timediff(@SystemTime) <= 2592000000]]] and *[EventData[Data[@Name='LogonType']='10']]"
$rdpLogons = Get-WinEvent -LogName Security -FilterXPath $xp | ForEach-Object {
    $x = [xml]$_.ToXml(); $d = @{}; $x.Event.EventData.Data | ForEach-Object { $d[$_.Name] = $_.'#text' }
    [pscustomobject]@{ Time = $_.TimeCreated; User = "$($d.TargetDomainName)\$($d.TargetUserName)"; FromIP = $d.IpAddress }
}
$rdpSum = $rdpLogons | Group-Object User, FromIP | Select-Object Count, Name, @{n='Last';e={($_.Group | Select-Object -First 1).Time}}
Save $rdpSum '05-rdp-logons.csv'
$private = '^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|127\.|::1|fe80|-$)'
$ext = $rdpLogons | Where-Object { $_.FromIP -and $_.FromIP -notmatch $private } | Select-Object -ExpandProperty FromIP -Unique
if ($ext) { Flag 'Critical' ("Remote Desktop logons from internet addresses: " + ($ext -join ', ') + " - RDP may be exposed to the internet") }

Step 'Failed logons (last 7 days)'
$xp2 = "*[System[(EventID=4625) and TimeCreated[timediff(@SystemTime) <= 604800000]]]"
$fail = Get-WinEvent -LogName Security -FilterXPath $xp2 -MaxEvents 20000 | ForEach-Object {
    $x = [xml]$_.ToXml(); $d = @{}; $x.Event.EventData.Data | ForEach-Object { $d[$_.Name] = $_.'#text' }
    [pscustomobject]@{ User = $d.TargetUserName; FromIP = $d.IpAddress; Workstation = $d.WorkstationName }
}
$failSum = $fail | Group-Object User, FromIP | Sort-Object Count -Descending | Select-Object -First 50 Count, Name
Save $failSum '05-failed-logons.csv'
$fc = @($fail).Count
if ($fc -gt 500)     { Flag 'Critical' "$fc failed logons in 7 days (password guessing?) - see 05-failed-logons.csv" }
elseif ($fc -gt 100) { Flag 'Warning'  "$fc failed logons in 7 days - see 05-failed-logons.csv" }

Step 'SMBv1 and firewall'
$smb = Get-SmbServerConfiguration
if ($smb.EnableSMB1Protocol) { Flag 'Warning' 'SMBv1 (old, insecure file sharing) is enabled' }
$fw = Get-NetFirewallProfile | Select-Object Name, Enabled, DefaultInboundAction
Save $fw '05-firewall.csv'
foreach ($p in $fw | Where-Object { -not $_.Enabled }) { Flag 'Warning' "Windows Firewall profile '$($p.Name)' is OFF" }

Step 'Security log size'
$sec = Get-WinEvent -ListLog Security
SaveText @("Security log max size MB : $([math]::Round($sec.MaximumSizeInBytes/1MB))", "Oldest kept event        : $((Get-WinEvent -LogName Security -Oldest -MaxEvents 1).TimeCreated)") '05-security-log.txt'
