﻿# G1 server assessment - Section 3: What runs on the server
# Roles, shares, share permissions and sizes, connected clients, installed software, databases,
# non-Microsoft services, listening ports, scheduled tasks. READ-ONLY.
# -Quick skips the slow parts (share sizes and the database-file search).
param([string]$OutDir, [switch]$Quick)
. (Join-Path $PSScriptRoot '_common.ps1')
$Area = '3 Services'

Step 'Windows roles'
$roles = Get-WindowsFeature | Where-Object { $_.Installed -and $_.FeatureType -eq 'Role' } | Select-Object DisplayName, Name
Save $roles '02-roles.csv'
if ($roles) { Flag 'Info' ("Roles: " + (($roles.DisplayName) -join ', ')) }

Step 'Shared folders and permissions'
$shares = Get-SmbShare | Where-Object { $_.Name -notmatch '\$$' } | Select-Object Name, Path, Description
Save $shares '02-shares.csv'
$access = foreach ($s in $shares) { Get-SmbShareAccess -Name $s.Name | Select-Object Name, AccountName, AccessControlType, AccessRight }
Save $access '02-share-access.csv'
$everyoneFull = $access | Where-Object { $_.AccountName -match 'Everyone|\\Users$|Authenticated Users' -and $_.AccessRight -eq 'Full' -and $_.AccessControlType -eq 'Allow' }
foreach ($e in $everyoneFull) { Flag 'Warning' "Share '$($e.Name)' gives Full access to $($e.AccountName)" }

if (-not $Quick) {
    Step 'Share sizes (can take a few minutes)'
    $sizes = foreach ($s in $shares | Where-Object Path) {
        $m = Get-ChildItem -LiteralPath $s.Path -Recurse -File -Force | Measure-Object Length -Sum
        [pscustomobject]@{ Share = $s.Name; Path = $s.Path; Files = $m.Count; SizeGB = [math]::Round($m.Sum / 1GB, 1) }
    }
    Save $sizes '02-share-sizes.csv'
}

Step 'Connected clients'
Save (Get-SmbSession | Select-Object ClientComputerName, ClientUserName, NumOpens, SecondsExists) '02-connected-clients.csv'

Step 'Installed software'
$sw = Get-InstalledSoftware
Save $sw '02-software.csv'
$remote = $sw | Where-Object DisplayName -match 'AnyDesk|TeamViewer|RustDesk|UltraViewer|Radmin|VNC|Supremo|AnyViewer|Splashtop|ScreenConnect|Ammyy'
foreach ($r in $remote) { Flag 'Warning' "Remote-access tool installed: $($r.DisplayName) (who uses it?)" }

Step 'Databases'
$db = Get-Service | Where-Object { $_.Name -match '^MSSQL|^SQLAgent|^MySQL|^postgresql|^MariaDB|^OracleService' } |
      Select-Object Name, DisplayName, Status, StartType
Save $db '02-database-services.csv'
if ($db) { Flag 'Info' ("Database services: " + (($db.Name) -join ', ')) }

if (-not $Quick -and $db) {
    Step 'Database files on all fixed drives (can take a few minutes)'
    $drives = Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object { $_.DeviceID + '\' }
    $files = foreach ($d in $drives) {
        Get-ChildItem -Path $d -Recurse -File -Force -Include *.mdf, *.ldf, *.ndf, *.bak |
            Where-Object { $_.FullName -notmatch '^[A-Z]:\\(Windows|\$Recycle\.Bin)\\' } |
            Select-Object FullName, @{n='SizeMB';e={[math]::Round($_.Length/1MB)}}, LastWriteTime
    }
    Save $files '02-database-files.csv'
}

Step 'Non-Microsoft services'
$svc = Get-CimInstance Win32_Service | Where-Object { $_.State -eq 'Running' -and $_.PathName -notmatch '\\Windows\\' } |
       Select-Object DisplayName, Name, StartMode, StartName, PathName
Save $svc '02-services-nonmicrosoft.csv'
$userSvc = Get-CimInstance Win32_Service | Where-Object { $_.StartName -and $_.StartName -notmatch '^(LocalSystem|NT AUTHORITY\\|NT SERVICE\\|LocalService|NetworkService)' }
foreach ($u in $userSvc) { Flag 'Warning' "Service '$($u.DisplayName)' runs as user account $($u.StartName) (breaks if that password changes)" }

Step 'Listening ports'
$ports = Get-NetTCPConnection -State Listen | ForEach-Object {
    $p = Get-Process -Id $_.OwningProcess
    [pscustomobject]@{ Port = $_.LocalPort; Address = $_.LocalAddress; Process = $p.ProcessName; Path = $p.Path }
} | Sort-Object Port, Process -Unique
Save $ports '02-listening-ports.csv'

Step 'Scheduled tasks (non-Microsoft)'
$tasks = Get-ScheduledTask | Where-Object { $_.TaskPath -notlike '\Microsoft\*' } | ForEach-Object {
    $i = $_ | Get-ScheduledTaskInfo
    [pscustomobject]@{
        Task = $_.TaskName; Path = $_.TaskPath; State = $_.State; RunsAs = $_.Principal.UserId
        LastRun = $i.LastRunTime; LastResult = $i.LastTaskResult; NextRun = $i.NextRunTime
        Action = ($_.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)".Trim() }) -join '; '
    }
}
Save $tasks '02-scheduled-tasks.csv'
foreach ($t in $tasks | Where-Object { $_.LastResult -notin 0, 267009, 267011, $null -and $_.State -ne 'Disabled' }) {
    Flag 'Warning' "Scheduled task '$($t.Task)' last result was not success (code $($t.LastResult))"
}
