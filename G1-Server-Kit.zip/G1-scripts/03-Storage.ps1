﻿# G1 server assessment - Section 4: Disks and storage
# Physical disks, volumes/free space, disk wear, disk errors in the event log, RAID controllers,
# Storage Spaces and software mirrors. READ-ONLY.
param([string]$OutDir, [switch]$Quick)
. (Join-Path $PSScriptRoot '_common.ps1')
$Area = '4 Storage'

Step 'Physical disks'
$pd = Get-PhysicalDisk | Select-Object DeviceId, FriendlyName, SerialNumber, MediaType, BusType,
        @{n='SizeGB';e={[math]::Round($_.Size/1GB)}}, HealthStatus, OperationalStatus
Save $pd '03-physical-disks.csv'
foreach ($d in $pd | Where-Object { $_.HealthStatus -and $_.HealthStatus -ne 'Healthy' }) {
    Flag 'Critical' "Disk '$($d.FriendlyName)' health is $($d.HealthStatus) / $($d.OperationalStatus)"
}

Step 'Volumes and free space'
$vol = Get-Volume | Where-Object { $_.DriveLetter -and $_.DriveType -eq 'Fixed' } | Select-Object DriveLetter, FileSystemLabel, FileSystem,
        @{n='SizeGB';e={[math]::Round($_.Size/1GB)}}, @{n='UsedGB';e={[math]::Round(($_.Size-$_.SizeRemaining)/1GB)}},
        @{n='FreeGB';e={[math]::Round($_.SizeRemaining/1GB)}},
        @{n='FreePct';e={ if ($_.Size) { [math]::Round($_.SizeRemaining/$_.Size*100) } }}, HealthStatus,
        @{n='Date';e={Get-Date -Format 'yyyy-MM-dd'}}
Save $vol '03-volumes.csv'
foreach ($v in $vol) {
    if ($v.FreePct -lt 10)     { Flag 'Critical' "Drive $($v.DriveLetter): only $($v.FreePct)% free ($($v.FreeGB) GB)" }
    elseif ($v.FreePct -lt 20) { Flag 'Warning'  "Drive $($v.DriveLetter): only $($v.FreePct)% free ($($v.FreeGB) GB)" }
}

Step 'Disk wear counters'
$rel = Get-PhysicalDisk | ForEach-Object {
    $c = $_ | Get-StorageReliabilityCounter
    [pscustomobject]@{ Disk = $_.FriendlyName; TemperatureC = $c.Temperature; WearPct = $c.Wear
                       ReadErrorsUncorrected = $c.ReadErrorsUncorrected; WriteErrorsUncorrected = $c.WriteErrorsUncorrected
                       PowerOnHours = $c.PowerOnHours; PowerOnYears = if ($c.PowerOnHours) { [math]::Round($c.PowerOnHours/8760,1) } }
}
Save $rel '03-disk-wear.csv'
foreach ($r in $rel | Where-Object { $_.ReadErrorsUncorrected -gt 0 -or $_.WriteErrorsUncorrected -gt 0 }) {
    Flag 'Critical' "Disk '$($r.Disk)' has uncorrected read/write errors"
}
foreach ($r in $rel | Where-Object { $_.WearPct -ge 80 }) { Flag 'Warning' "SSD '$($r.Disk)' wear is $($r.WearPct)%" }

Step 'Disk errors in the event log (last 90 days)'
$ev = Get-WinEvent -FilterHashtable @{ LogName = 'System'; Level = 1,2,3; StartTime = (Get-Date).AddDays(-90) } |
      Where-Object { $_.ProviderName -match 'disk|Ntfs|storahci|stornvme|iaStor|megasas|megasr|percsas|HpCISSs|smartpqi|arcsas|LSI' }
$evSum = $ev | Group-Object ProviderName, Id | Select-Object Count, Name, @{n='Last';e={($_.Group | Select-Object -First 1).TimeCreated}},
         @{n='Example';e={(($_.Group | Select-Object -First 1).Message -split "`n")[0]}}
Save $evSum '03-disk-events.csv'
$bad = $ev | Where-Object { ($_.ProviderName -eq 'disk' -and $_.Id -in 7, 51, 153) -or ($_.ProviderName -eq 'Ntfs' -and $_.Id -in 55, 98) }
if ($bad) { Flag 'Critical' "$(@($bad).Count) disk/file-system errors in 90 days (bad blocks / corruption). Check NOW - see 03-disk-events.csv" }
elseif ($ev) { Flag 'Warning' "$(@($ev).Count) storage warnings/errors in 90 days - see 03-disk-events.csv" }

Step 'RAID controllers'
$ctl = Get-CimInstance Win32_SCSIController | Select-Object Name, Manufacturer, DriverName, Status
Save $ctl '03-storage-controllers.csv'
$hwRaid = $ctl | Where-Object Name -match 'Smart Array|SmartRAID|PERC|MegaRAID|LSI|Broadcom|Avago|RAID|Adaptec|ServeRAID|ThinkSystem'
if ($hwRaid) {
    Flag 'Info' ("Hardware RAID controller: " + (($hwRaid.Name) -join ', ') + ". Check RAID status by hand in iLO/iDRAC or the vendor RAID tool (section 4.3)")
} else {
    Flag 'Info' 'No hardware RAID controller detected. Check for software RAID (03-virtual-disks / 03-diskpart-volumes) or Intel RST'
}

Step 'Storage Spaces and software mirrors'
$vd = Get-VirtualDisk | Select-Object FriendlyName, ResiliencySettingName, @{n='SizeGB';e={[math]::Round($_.Size/1GB)}}, HealthStatus, OperationalStatus
Save $vd '03-virtual-disks.csv'
foreach ($v in $vd | Where-Object { $_.HealthStatus -ne 'Healthy' }) { Flag 'Critical' "Storage Space '$($v.FriendlyName)' is $($v.HealthStatus) / $($v.OperationalStatus)" }
$dp = 'list volume' | diskpart.exe
SaveText $dp '03-diskpart-volumes.txt'
if ($dp -match 'Mirror|RAID-5' -and $dp -match 'Failed|Rebuild|Redundancy') { Flag 'Critical' 'Software RAID volume is failed/rebuilding - see 03-diskpart-volumes.txt' }

if (-not $hwRaid -and -not $vd -and -not ($dp -match 'Mirror|RAID-5') -and @($pd).Count -le 1) {
    Flag 'Critical' 'Only one disk and no RAID found: a single disk failure means data loss and downtime'
}
