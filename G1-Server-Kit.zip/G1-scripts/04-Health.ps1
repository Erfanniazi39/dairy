﻿# G1 server assessment - Section 5: Health and maintenance
# Updates, pending reboot, uptime, antivirus, recurring errors, unexpected shutdowns, time sync. READ-ONLY.
param([string]$OutDir, [switch]$Quick)
. (Join-Path $PSScriptRoot '_common.ps1')
$Area = '5 Health'

Step 'Update history'
$hist = @()
try {
    $searcher = (New-Object -ComObject Microsoft.Update.Session).CreateUpdateSearcher()
    $n = $searcher.GetTotalHistoryCount()
    if ($n -gt 0) {
        $hist = $searcher.QueryHistory(0, [math]::Min($n, 100)) | Where-Object { $_.Title } | ForEach-Object {
            [pscustomobject]@{ Date = $_.Date; Title = $_.Title
                               Result = @{1='In progress';2='Succeeded';3='Succeeded with errors';4='Failed';5='Aborted'}[[int]$_.ResultCode] }
        }
    }
} catch {}
Save $hist '04-update-history.csv'
$hotfix = Get-HotFix | Select-Object HotFixID, Description, InstalledOn | Sort-Object InstalledOn -Descending
Save $hotfix '04-hotfixes.csv'

$lastOk = @(($hist | Where-Object Result -like 'Succeeded*' | Sort-Object Date -Descending | Select-Object -First 1).Date,
            ($hotfix | Where-Object InstalledOn | Select-Object -First 1).InstalledOn) | Where-Object { $_ } | Sort-Object -Descending | Select-Object -First 1
if (-not $lastOk)                              { Flag 'Critical' 'No record of any installed update found' }
elseif ($lastOk -lt (Get-Date).AddDays(-60))   { Flag 'Warning'  ("Last update installed {0:yyyy-MM-dd} ({1} days ago)" -f $lastOk, ((Get-Date) - $lastOk).Days) }
else                                           { Flag 'Info'     ("Last update installed {0:yyyy-MM-dd}" -f $lastOk) }
$failed = @($hist | Where-Object { $_.Result -eq 'Failed' -and $_.Date -gt (Get-Date).AddDays(-90) })
if ($failed.Count) { Flag 'Warning' "$($failed.Count) failed update installs in the last 90 days" }

Step 'Pending reboot and uptime'
$pending = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') -or
           (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')
$os = Get-CimInstance Win32_OperatingSystem
$uptime = (Get-Date) - $os.LastBootUpTime
SaveText @("Last boot      : $($os.LastBootUpTime)", "Uptime (days)  : $([math]::Round($uptime.TotalDays,1))", "Reboot pending : $pending") '04-uptime.txt'
if ($pending)              { Flag 'Warning' 'A restart is pending to finish installing updates' }
if ($uptime.TotalDays -gt 90) { Flag 'Warning' "Server has not restarted for $([int]$uptime.TotalDays) days (updates probably not applied)" }

Step 'Antivirus'
$def = Get-MpComputerStatus
$avSw = Get-InstalledSoftware | Where-Object DisplayName -match 'Kaspersky|ESET|NOD32|Symantec|McAfee|Sophos|Bitdefender|Trend Micro|Avast|AVG|Padvish|Avira|Panda|Comodo|Malwarebytes|CrowdStrike|SentinelOne|Webroot'
$avRows = @()
if ($def) { $avRows += [pscustomobject]@{ Product = 'Microsoft Defender'; Enabled = $def.AMServiceEnabled; RealTime = $def.RealTimeProtectionEnabled
                                          SignaturesUpdated = $def.AntivirusSignatureLastUpdated; SignatureAgeDays = $def.AntivirusSignatureAge } }
$avRows += $avSw | ForEach-Object { [pscustomobject]@{ Product = $_.DisplayName; Enabled = 'check in product'; RealTime = ''; SignaturesUpdated = ''; SignatureAgeDays = '' } }
Save $avRows '04-antivirus.csv'
if (-not $avSw -and (-not $def -or -not $def.RealTimeProtectionEnabled)) { Flag 'Critical' 'No active antivirus found' }
elseif (-not $avSw -and $def.AntivirusSignatureAge -gt 7)               { Flag 'Warning'  "Defender signatures are $($def.AntivirusSignatureAge) days old" }
elseif ($avSw) { Flag 'Info' ("Antivirus: " + (($avSw.DisplayName) -join ', ') + " - open it and check the last update date by hand") }

Step 'Recurring errors (last 30 days)'
$err = Get-WinEvent -FilterHashtable @{ LogName = 'System','Application'; Level = 1,2; StartTime = (Get-Date).AddDays(-30) } |
       Group-Object ProviderName, Id | Sort-Object Count -Descending | Select-Object -First 25 Count, Name,
       @{n='Example';e={(($_.Group | Select-Object -First 1).Message -split "`n")[0]}}
Save $err '04-top-errors.csv'

Step 'Unexpected shutdowns (last 180 days)'
$sd = Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = 41, 6008; StartTime = (Get-Date).AddDays(-180) } |
      Select-Object TimeCreated, Id, @{n='Message';e={($_.Message -split "`n")[0]}}
Save $sd '04-unexpected-shutdowns.csv'
$sdCount = @($sd | Where-Object Id -eq 6008).Count
if ($sdCount -ge 3)     { Flag 'Warning' "$sdCount unexpected shutdowns in 180 days (power cuts or crashes - check UPS)" }
elseif ($sdCount -ge 1) { Flag 'Info'    "$sdCount unexpected shutdown(s) in 180 days" }

Step 'Time sync'
$t = @(w32tm /query /status 2>&1) + '' + @(w32tm /query /source 2>&1)
SaveText $t '04-time.txt'
if (($t -join ' ') -match 'Local CMOS Clock|Free-running') { Flag 'Warning' 'Server clock is not synced to any time source' }
